import products from '../model/productModel.js';
import asyncHandler from 'express-async-handler';
import { createProfile } from './users.js';
import { protect } from '../utils/usersMiddleware.js';

export const getProducts = asyncHandler( async (req , res) => {

        let productsList = await products.find();
        res.json(productsList);

});

export const getProductById = asyncHandler(async (req , res) => {

    const productsList = await products.findById(req.params.id);
    if(productsList)
        res.json(productsList);
    else {
        res.status(404);
        throw new Error
    }

})

export const removeProduct = asyncHandler(async(req , res) => {
  const id = req.params.id;

  const product = await products.findById(id);

  if(product){
    await product.remove();
    res.json({message : "product removed successfully"})
  } else {
    res.status(404).json({message : "product not found"})  
    throw new Error('product Not found')
  }
})

export const updateProduct = asyncHandler(async (req, res) => {
  const {
    name,
    price,
    description,
    image,
    brand,
    category,
    countInStock,
  } = req.body

  const product = await products.findById(req.params.id)

  if (product) {
    product.name = name
    product.price = price
    product.description = description
    product.image = image
    product.brand = brand
    product.category = category
    product.countInStock = countInStock

    const updatedProduct = await product.save()
    res.json(updatedProduct)
  } else {
    res.status(404)
    throw new Error('Product not found')
  }
})

export const generateProduct = asyncHandler(async (req, res) => {

try {

    const product = new products;
    product.name = 'Sample product'
    product.price = 300
    product.description = 'This is sameple product description'
    product.image = '/images/airpods'
    product.brand = 'DM'
    product.category = 'Entertainment'
    product.countInStock = 5
    product.user = req.user._id

    const createdProduct = await product.save();
    
    res.json(createdProduct);

} catch (error) {
      throw new Error(error)

}})


export const addReviews = asyncHandler(async (req , res) => {
  const product = await products.findById(req.params.id)

  const {rating , comment} = req.body;

  if(product) {
    const existReview = product.reviews.find(r => r.user.toString() == req.user._id.toString())

    if(existReview){
      res.status(400).json({message : "Review already exits"});
      throw new Error ('Review already exists');
    } else {
          const reviews = {
      name : req.user.name,
      comment : comment,
      user : req.user._id,
      rating : rating,
    }

    product.reviews.push(reviews)
    product.numReviews = product.reviews.length;
    product.rating = product.reviews.reduce((acc , item) => (item.rating + acc) ,0 )/product.reviews.length;

    await product.save();

    res.status(201).json({message : "Review Added"});
    }

  } else {
    res.status(404).send({message: "Not found"})
  }
})