import users from '../model/userModel.js'
import asyncHandler from 'express-async-handler';
import  { generateToken } from '../utils/generateToken.js'
import User from '../model/userModel.js';

export const authLogin = asyncHandler( async (req , res) => {

    let email = req.body.email;
    let password = req.body.password;

    let user = await users.findOne({email});
    
    if (user && (await user.matchPassword(password))) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      token: generateToken(user._id),
    })
  } else {
    res.status(401)
    throw new Error('Invalid email or password')
  }
});

export const getProfile = asyncHandler(async (req , res) => {

    const user = await users.findById(req.user._id);

     if (user) {

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    })

  } else {
    res.status(404)
    throw new Error('User not found')
  }
}
);


export const createProfile = asyncHandler(async (req , res) => {

    const {name , email , password} = req.body;

     const userExists = await User.findOne({ email })

    if (userExists) {
    res.status(400)
    throw new Error('User already exists')
    }

    let user = await User.create({
        email,
        password,
        name
    })

    if (user) {
    res.status(201).json({

      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      token: generateToken(user._id)

    })
    } else {
        res.status(400)
        throw new Error('Invalid user data')
    }
});

export const updateProfile = asyncHandler(async(req, res) => {
  const {name, email , password} = req.body;

  if(password) {
    await User.findByIdAndUpdate(req.body.id, {name , email , password});
  } else {
    await User.findByIdAndUpdate(req.body.id , {name , email }); 
  }

  const user = User.findByIdAndUpdate(req.body.id);

  res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      token: generateToken(user._id)
  })
});

export const getAllUsers = asyncHandler(async(req, res) => {

  const users = await User.find({});

  res.json(users);

}) 

export const removeUser = asyncHandler(async(req , res) => {
  const id = req.params.id;

  const user = await User.findById(id);

  if(user){
    await user.remove();
    res.json({message : "user removed successfully"})
  } else {
    res.status(404).json({message : "user not found"})  
    throw new Error('User Not found')
  }
})

export const getUserById = asyncHandler(async(req , res) => {

  const id = req.params.id;

  const user = await User.findById(id);

  if(user){
    res.json(user);
  } else {
    res.status(404).json({message : "user not found"})  
    throw new Error('User Not found')
  }
})

export const updateUser = asyncHandler(async(req, res) => {
  const {name, email , isAdmin} = req.body;

  const userId = req.params.id;

  const user = await User.findById(userId);

  if(user) {
    user.name = name;
    user.email = email;
    user.isAdmin = isAdmin;

    try {
      await user.save();
      res.send('successfully updated');
    } catch (error) {
      res.status(401).send(eror);
    }
  } else {
    res.status(404);
    throw new Error('user not found')
  }


});