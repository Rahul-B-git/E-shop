import mongoose from 'mongoose';

const connectdb = async () => {

    try {
        mongoose.connect('mongodb+srv://test:manu1234@cluster0.lw9ya.mongodb.net/test?retryWrites=true&w=majority' , {useUnifiedTopology: true,
        useNewUrlParser: true,
        useCreateIndex: true});

        console.log('Server connected');
    }

    catch (error) {
        console.log('error');
    }
}

export default connectdb;