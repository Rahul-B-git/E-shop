import express from 'express';
import mongoose from 'mongoose';
import Productsrouter from './routes/Products.js';
import usersrouter from './routes/users.js';
import cors from 'cors';
import connectDB from './configs/connectdb.js'
import { notFound, errorHandler } from './errors.js'
import orders from './routes/orders.js'
import upload from './routes/upload.js'
import path from 'path'

connectDB();

let app = express();

app.use(express.json());
app.use(express.urlencoded({extended : true}));
app.use(cors());

app.use('/api/products' , Productsrouter);
app.use('/api/users' , usersrouter);
app.use('/api/orders' , orders);
app.use('/api/upload' , upload);


const __dirname = path.resolve()
app.use('/uploads' , express.static(path.join(__dirname , '/uploads')))

//paypal client id
app.get('/api/configs/paypal' , (req , res) => res.send('AVZv3jwR9Hbc9SVejuWipl9KdLJbeC_agYenfYwQ06XnqybAjut_MLsXQvOkAoQPLBCOpQByRvWYAOy2'));

app.use(notFound);

app.use(errorHandler);

app.listen(5000);