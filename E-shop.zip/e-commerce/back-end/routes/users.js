import express from 'express'
import { authLogin, createProfile, getProfile , updateProfile , getAllUsers , removeUser, getUserById, updateUser} from '../controllers/users.js'
import {protect , admin} from '../utils/usersMiddleware.js'

let router = express.Router();

router.get('/' , protect , admin , getAllUsers)
router.post('/register' , createProfile );
router.post('/login' , authLogin );
router.get('/profile' , protect , getProfile ).put('/profile' , protect , updateProfile);
router.delete('/remove/:id' , protect , admin , removeUser);
router.get('/:id' , protect , admin , getUserById);
router.put('/:id' , protect , admin , updateUser)
export default router;
