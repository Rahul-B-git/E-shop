import express from 'express'
const router = express.Router()
import { updateOrderIsDelivered , addOrderItems, getMyOrders, getOrderById, getOrders, updateOrderToPaid } from '../controllers/orders.js'
import {protect , admin}  from '../utils/usersMiddleware.js'

router.post('/' , protect , addOrderItems).get('/' , protect , admin , getOrders);
router.get('/myorders', protect , getMyOrders)
router.get('/:id' , protect , getOrderById);
router.put('/:id/pay' , updateOrderToPaid);
router.put('/:id/deliver' ,protect , admin ,  updateOrderIsDelivered);
export default router;