import express from 'express'
import { addReviews, generateProduct, getProductById, getProducts , removeProduct, updateProduct } from '../controllers/products.js';
import {protect , admin} from '../utils/usersMiddleware.js'

let router = express.Router();

router.get('/' , getProducts );

router.post('/:id/reviews' , protect , addReviews);

router.get('/generate' , protect , admin , generateProduct);

router.get('/:id' , getProductById ).put( '/:id' ,protect , admin , updateProduct);


router.delete('/remove/:id' , protect , admin , removeProduct);



export default router;
