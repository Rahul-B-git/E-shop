import { act } from "react-dom/test-utils";
import { USER_EDIT_ERROR , USER_EDIT_SUCCESS , USER_EDIT_REQUEST,  USERS_GET_ERROR, USERS_GET_REQUEST, USERS_GET_SUCCESS, USER_DELETE_ERROR, USER_DELETE_REQUEST, USER_DELETE_SUCCESS, USER_EDIT_GET_ERROR, USER_EDIT_GET_REQUEST, USER_EDIT_GET_SUCCESS, USER_GET_ERROR, USER_GET_REQUEST, USER_GET_SUCCESS, USER_LOGIN_ERROR, USER_LOGIN_REQUEST, USER_LOGIN_SUCCESS, USER_LOGOUT, USER_REGISTER_ERROR, USER_REGISTER_REQUEST, USER_REGISTER_SUCCESS, USER_EDIT_GET_RESET } from "../Components/constants/userConstants";

export const userLoginReducer = (state = {userData : {}} , action) => {
    switch(action.type) {
        case USER_LOGIN_REQUEST :
            return { loading : true , state};
        case USER_LOGIN_SUCCESS :
            return ({ loading : false , userData : action.payload });
        case USER_LOGIN_ERROR : 
            return ({ loading : false , error : action.payload });
        case USER_LOGOUT : 
            return ({})
        default : 
            return state;
    }
}

export const userRegisterReducer = (state = {} , action) => {
    switch(action.type) {
        case USER_REGISTER_REQUEST :
            return { loading : true , state};
        case USER_REGISTER_SUCCESS :
            return ({ loading : false , userData : action.payload });
        case USER_REGISTER_ERROR : 
            return ({ loading : false , error : action.payload });
        default : 
            return state;
    }
}

export const userGetProfileReducer = (state = {} , action) => {
    switch(action.type) {
        case USER_GET_REQUEST :
            return { loading : true , state};
        case USER_GET_SUCCESS :
            return ({ loading : false , userData : action.payload });
        case USER_GET_ERROR : 
            return ({ loading : false , error : action.payload });
        default : 
            return state;
    }
}


export const getAllUsersReducers = (state = {users : [] , loading : true} , action) => {
    switch(action.type) {
        case USERS_GET_REQUEST : 
            return {loading : true}
        case USERS_GET_SUCCESS :
            return {loading : false , users : action.payload}
        case USERS_GET_ERROR :
            return {loading : false , error : action.payload}
        default : 
            return state
    }
}

export const deleteUserReducer = (state = {loading : true} , action) => {
    switch(action.type) {
        case USER_DELETE_REQUEST : 
            return {loading : true}
        case USER_DELETE_SUCCESS :
            return {loading : false , success : true }
        case USER_DELETE_ERROR :
            return {loading : false , success : false , error : action.payload}
        default : 
            return state
    }
}

export const getUserEditReducer = (state = {loading : true} , action) => {
    switch(action.type) {
        case USER_EDIT_GET_REQUEST : 
            return {loading : true , success : false}
        case USER_EDIT_GET_SUCCESS :
            return {loading : false , userData : action.payload}
        case USER_EDIT_GET_ERROR :
            return {loading : false , error : action.payload}
        case USER_EDIT_GET_RESET:
            return {}
        default : 
            return state
    }
}

export const updateUserReducer = (state = {loading : true , success : false} , action) => {
    switch(action.type) {
        case USER_EDIT_REQUEST : 
            return {loading : true}
        case USER_EDIT_SUCCESS:
            return {loading : false , success : true}
        case USER_EDIT_ERROR :
            return {loading : false , success : false ,error : action.payload}
        default : 
            return state
    }
}