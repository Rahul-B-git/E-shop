import {combineReducers} from 'redux';
import { productGenerateReducer, productReducers , productReviewReducer, productsReducers, productUpdateReducer } from './productReducers';
import {addToCartReducer} from './cartReducers'
import {getAllUsersReducers, getUserEditReducer, updateUserReducer, userGetProfileReducer, userLoginReducer, userRegisterReducer} from './userReducers'
import { orderDeliverReducer, orderDetailsReducer, orderListMyReducer, orderListReducer, orderPayReducer, paymentMethodReducer, saveOrderReducer, shippingReducer } from './orderReducer';

const reducers = combineReducers({
    productsReducer : productsReducers,
    productReducers,
    productUpdate : productUpdateReducer,
    generatedProduct : productGenerateReducer,
    cart : addToCartReducer,
    userLogin : userLoginReducer,
    userRegister : userRegisterReducer,
    userProfile : userGetProfileReducer,
    allUsers : getAllUsersReducers,
    updateUser : updateUserReducer,
    address : shippingReducer,
    paymentMethod : paymentMethodReducer,
    order : saveOrderReducer,
    orderDetails : orderDetailsReducer,
    orderPay : orderPayReducer,
    orderListMy : orderListMyReducer,
    userDetails : getUserEditReducer,
    allOrders : orderListReducer,
    orderDeliver : orderDeliverReducer,
    addReview: productReviewReducer,
});

export default reducers