import { PRODUCT_GET_RESET, PRODUCTS_LOAD_STATE, PRODUCTS_GET_ERROR  , PRODUCTS_GET_STATE , PRODUCT_GET_ERROR ,PRODUCT_GET_STATE , PRODUCT_LOAD_STATE, PRODUCT_DELETE_REQUEST, PRODUCT_DELETE_SUCCESS, PRODUCT_DELETE_ERROR, PRODUCT_UPDATE_REQUEST, PRODUCT_UPDATE_SUCCESS, PRODUCT_UPDATE_ERROR, PRODUCT_UPDATE_RESET, PRODUCT_GENERATE_REQUEST, PRODUCT_GENERATE_SUCCESS, PRODUCT_GENERATE_ERROR, PRODUCT_GENERATE_RESET, PRODUCTS_GET_RESET, PRODUCT_REVIEW_REQUEST, PRODUCT_REVIEW_SUCCESS, PRODUCT_REVIEW_ERROR, PRODUCT_REVIEW_RESET} from '../Components/constants/constants';
import { fetchProducts  , fetchProduct} from '../actions/productActions'

export const productsReducers = (state = { products : [] , loading : true } , action) => {
    switch(action.type) {
        case PRODUCTS_LOAD_STATE :
            return { loading : true , products : []};
        case PRODUCTS_GET_STATE :
            return ({ loading : false , products : action.payload});
        case PRODUCTS_GET_ERROR : 
            return ({ loading : false , error : action.error });
        case PRODUCTS_GET_RESET : 
            return ({products : []});
        default : 
            return state
    }
}

export const productReducers = (state = { product : { reviews : []} } , action) => {
    switch(action.type) {
        case PRODUCT_LOAD_STATE :
            return { ...state ,  loading : true };
        case PRODUCT_GET_STATE :
            return ({ loading : false , product : action.payload});
        case PRODUCT_GET_ERROR : 
            return ({ loading : false , error : action.error });
        case PRODUCT_GET_RESET :
            return ({loading : false})
        default : 
            return state
    }
}
export const deleteProductReducer = (state = {loading : true} , action) => {
    switch(action.type) {
        case PRODUCT_DELETE_REQUEST : 
            return {loading : true}
        case PRODUCT_DELETE_SUCCESS :
            return {loading : false , success : true }
        case PRODUCT_DELETE_ERROR :
            return {loading : false , success : false , error : action.payload}
        default : 
            return state
    }
}

export const productUpdateReducer = (state = { product: {} }, action) => {
  switch (action.type) {
    case PRODUCT_UPDATE_REQUEST:
      return { loading: true }
    case PRODUCT_UPDATE_SUCCESS:
      return { loading: false, success: true, product: action.payload }
    case PRODUCT_UPDATE_ERROR:
      return { loading: false, error: action.payload }
    case PRODUCT_UPDATE_RESET:
      return { product: {} }
    default:
      return state
  }
}

export const productGenerateReducer = (state = {}, action) => {
  switch (action.type) {
    case PRODUCT_GENERATE_REQUEST:
      return { loading: true }
    case PRODUCT_GENERATE_SUCCESS:
      return { loading: false, success: true, product: action.payload }
    case PRODUCT_GENERATE_ERROR:
      return { loading: false, success : false , error: action.payload }
    case PRODUCT_GENERATE_RESET:
      return { product: {} }
    default:
      return state
  }
}

export const productReviewReducer = (state = {}, action) => {
  switch (action.type) {
    case PRODUCT_REVIEW_REQUEST:
      return { loading: true }
    case PRODUCT_REVIEW_SUCCESS:
      return { loading: false, success: true }
    case PRODUCT_REVIEW_ERROR:
      return { loading: false, success : false , error: action.payload }
    case PRODUCT_REVIEW_RESET:
      return {loading : false , success : false}
    default:
      return state
  }
}

