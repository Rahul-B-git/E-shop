import cartActions from '../actions/cartActions'
import {ADD_TO_CART , REMOVE_FROM_CART} from'../Components/constants/constants'
export const addToCartReducer = (state = {cartItems : []} , action) => {


    switch(action.type) {
        case ADD_TO_CART : 
            const item = action.payload

            const existItem = state.cartItems.find((x) => x.product === item.product)

            if (existItem) {
                return {
                ...state,
                cartItems: state.cartItems.map((x) =>
                    x.product === existItem.product ? item : x
                ),
                }
            } else {
                return {
                ...state,
                cartItems: [...state.cartItems, item],
                }
            };

        case REMOVE_FROM_CART :
            const id = action.payload.id
            
            return {...state , cartItems : state.cartItems.filter(item => item.product != id) }
            
        default : {
            return state
        }
    }
}