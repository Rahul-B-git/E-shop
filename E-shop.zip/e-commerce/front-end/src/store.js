import {createStore , compose , applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import reducer from './reducers/index.js'
import { composeWithDevTools } from 'redux-devtools-extension';

const middleware = [thunk];

const cartItemsFromStorage = localStorage.getItem('cartItems')
  ? JSON.parse(localStorage.getItem('cartItems'))
  : [];

const loginFromStorage = localStorage.getItem('userData') ? 
  JSON.parse(localStorage.getItem('userData'))
  : null

const shippingAddress = localStorage.getItem('ShippingAddress') ? 
  JSON.parse(localStorage.getItem('ShippingAddress'))
  : {}

const paymentMethod = localStorage.getItem('PaymentMethod') ? 
  JSON.parse(localStorage.getItem('PaymentMethod'))
  : null


const initialState = {
  cart: { cartItems: cartItemsFromStorage },
  userLogin : {userData : loginFromStorage},
  address : shippingAddress,
  paymentMethod : paymentMethod
}

let store = createStore(reducer , initialState , composeWithDevTools(compose(applyMiddleware(...middleware))));

export default store;