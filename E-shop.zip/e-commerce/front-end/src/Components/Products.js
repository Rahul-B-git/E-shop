import React, { useEffect } from 'react'
import {useDispatch , useSelector} from 'react-redux'
import { Link } from 'react-router-dom'
import { deleteProduct, fetchProducts, generateProduct } from '../actions/productActions'
import '../css/products.css'
import { PRODUCT_GENERATE_RESET } from './constants/constants'


const Products = ({history}) => {

    const dispatch = useDispatch()

        const productsReducer = useSelector((state) => state.productsReducer);
        const { products , loading , error } = productsReducer;

        const generatedProduct = useSelector(state => state.generatedProduct);
        const {success , product} = generatedProduct

        if(!loading) {
            console.log(products)
        }

    useEffect(() => {
        if(success){
            dispatch(fetchProducts());
            setTimeout(() => history.push(`/admin/product/${product._id}`) , 1000);
        } else {
            if(products.length == 0){
                dispatch(fetchProducts());
            }
        }
    } , [dispatch , success , history ])


    const handleGenerate = (e) => {
        e.preventDefault();
        dispatch(generateProduct());
    }

    return (
        <>
        <p className="title"> Products </p>
        <button onClick={handleGenerate} className="right">Create Product</button>
        <table>
            <thead>
                <tr>
                    <td>ID</td>
                    <td>NAME</td>
                    <td>PRICE</td>
                    <td>CATEGORY</td>
                    <td>BRAND</td>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                {!loading && products.map(product => (
                    <tr key={product._id}>
                        <td>{product._id}</td>
                        <td>{product.name}</td>
                        <td>{product.price}</td>
                        <td>{product.category}</td>
                        <td>{product.brand}</td> 
                        <td>
                            <>
                            <Link to={`/admin/product/${product._id}`}>
                            <button>
                                <i style={{cursor: "pointer"}} className='fas fa-edit bg-white'></i>
                            </button>
                        </Link>
                        <button>
                            <i onClick={(e) => {
                                if(window.confirm('Are you sure ?')){
                                    dispatch(deleteProduct(product._id))
                                    setTimeout(() => dispatch(fetchProducts()) , 1000);
                                }
                                console.log(product._id)
                            }}  className='fas fa-trash bg-red'></i></button></>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
</>)
}

export default Products