import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
import {listOrders } from '../actions/orderActions';

const AllOrders = () => {

    const dispatch = useDispatch();

    const allOrders = useSelector(state => state.allOrders);
    const {loading , orders} = allOrders;

    useEffect(() => {
        dispatch(listOrders())
    },[dispatch])

    return (
        <>
            <table>
                    <thead>
                        <tr>
                        <td>ID</td>
                        <td>USER</td>
                        <td>DATE</td>
                        <td>TOTAL</td>
                        <td>PAID</td>
                        <td>DELIVERED</td>
                        <td />
                        </tr>
                    </thead>
                    <tbody>
                        {!loading && orders.map(order => (
                        <tr key={order._id}>
                        <td>{order._id}</td>
                        <td>{ order.user ? order.user.name : 'Admin'}</td>
                        <td>{order.createdAt.substring(0, 10)}</td>
                        <td>{order.totalPrice}</td>
                        <td>{order.isPaid ? (
                      order.paidAt.substring(0, 10)
                    ) : (
                      <i className='fas fa-times' style={{ color: 'red' }}></i>
                    )}</td>
                        <td>{order.isDelivered ? (
                      order.deliveredAt.substring(0, 10)
                    ) : (
                      <i className='fas fa-times' style={{ color: 'red' }}></i>
                    )}</td>
                        <td><Link to={`/order/${order._id}`}><button className="details">Details</button></Link></td>
                        </tr>
                    ))}
                    </tbody>
                    </table>
        </>
    )
}

export default AllOrders
