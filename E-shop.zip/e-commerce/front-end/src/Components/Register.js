import React, { useState ,useEffect } from 'react'
import { useDispatch , useSelector } from 'react-redux';
import { Link } from 'react-router-dom'
import { registerUser } from '../actions/userActions';
import '../css/login.css'

function Register({history}) {

    const [name , setName] = useState('');
    const [email , setEmail] = useState('');
    const [password , setPassword] = useState('');
    const [confirmPassword , setConfirmPassword] = useState('');

    const dispatch = useDispatch();

    const {error , userData , loading} = useSelector(state => state.userLogin);

    const handleSubmit = () => {
        if(password === confirmPassword)
        dispatch(registerUser(name , email , password));
    }

    useEffect( 
    () => {
    if(userData) {
        history.push('/')
    }
    }
    )

    return (
        <section id="login">
            <p className="title">Register</p>
            <div className="msg-container">
            </div>
            <div className="name-container">
                <label className="name-label">Name</label>
                <input onChange={(e) => setName(e.target.value)} type="name" placeholder="Your Name" htmlFor="name" />
            </div>
            <div className="email-container">
                <label className="email-label">Email Address</label>
                <input onChange={(e) => setEmail(e.target.value)} type="email" placeholder="email address" htmlFor="email" />
            </div>
            <div className="password-container">
                <label className="password-label">Password</label>
                <input type="password" onChange = {(e) => setPassword(e.target.value)} placeholder="Password" htmlFor="password" />
            </div>
            <div className="password-container">
                <label className="password-label">Confirm Password</label>
                <input type="password" onChange={(e) => setConfirmPassword(e.target.value)}  placeholder="Confirm Password" htmlFor="password" />
            </div>
            <button onClick={handleSubmit} className="submit">Submit</button>
            <div className="new">Have an account? <Link to='/login'> Login </Link></div>
        </section>

    )
}

export default Register
