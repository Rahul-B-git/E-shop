import React, { useState } from 'react'
import '../css/payments.css'
import Nav from './OrderNav'
import {savePaymentMethod} from '../actions/orderActions'
import { useDispatch } from 'react-redux'

const Payment = ({history}) => {

    const [method , setMethod] = useState('Paypal');

    const dispatch = useDispatch();

    const handleContinue = (e) => {
        dispatch(savePaymentMethod(method));
        history.push('/order')
    }


    return (
        <>
        <Nav step1 step2 step3/>
        <section id="payment-method">
        <p className="title">Payment Method</p>
        <div className="msg-container">
        </div>
        <label className="label" htmlFor="paymentmethod">Select Method</label>
        <br />
        <div className="paypal-container">
            <input type="radio" id="method" name="payment-method" value='Paypal' onChange={e => setMethod(e.target.value)} label="paypal" />
            <label className="label label-paypal" htmlFor="method">Paypal/ Card</label>
        </div>
        <button onClick={handleContinue} className="submit">Continue</button>
        </section>
        </>
    )
}

export default Payment