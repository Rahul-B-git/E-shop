import React from 'react'
import{Link} from 'react-router-dom'
import '../css/orderNav.css'

const OrderNav = ({step1 , step2 , step3 , step4}) => {
    return (
        <section id="navigate">
            <Link to="/login">
                {(step1 ==true ? <button className="nav">Step 1</button> : <button className="nav" disabled>Step 1</button> )}
            </Link>
            <Link to="/shipping">
                {(step2 == true ? <button className="nav">Step 2</button> : <button className="nav" disabled>Step 2</button> )}
            </Link>
            <Link to="/payment">
                {(step3 == true ? <button className="nav">Step 3</button> : <button className="nav" disabled>Step 3</button> )}
            </Link>
            <Link to="/order">
                {(step4 == true ? <button className="nav">Step 4</button> : <button className="nav" disabled>Step 4</button> )}
            </Link>
        </section>

    )
}

export default OrderNav
