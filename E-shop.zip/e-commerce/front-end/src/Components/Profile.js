import React, { useEffect, useState } from 'react'
import {useDispatch, useSelector} from 'react-redux'
import {getUser , updateUser} from '../actions/userActions'
import '../css/profile.css'
import {listMyOrders} from '../actions/orderActions'
import { Link } from 'react-router-dom'

const Profile = ({history}) => {

    const dispatch = useDispatch();
    const [name , setName] = useState('');
    const [email , setEmail] = useState('');
    const [password , setPassword] = useState('');
    const [confirmPassword , setConfirmPassword] = useState('');

    const userLogin = useSelector((state) => state.userLogin);

    
    const userProfile = useSelector((state) => state.userProfile);
    const {userData , loading , error} = userProfile;

    const myOrders = useSelector(state => state.orderListMy);
    const {orders , loading:loadingOrders} = myOrders;

    useEffect(
        async () => {
            if (!userLogin.userData) {
                history.push('/login')
            } else {
                if (!userData || !userData.name) {
                    dispatch(getUser());
                    dispatch(listMyOrders());
                }
                else {
                    setName(userData.name);
                    setEmail(userData.email);
                }
            }
            }
        , [dispatch, history , userData]);

        const handleUpdate = () => {
            if(password == confirmPassword) {
                dispatch(updateUser( userData._id , loading , name , email , password));
            }
        }

    return (
        <section id="profile">
            <div className="inside">
                <div className="user-profile">
                <p className="title">User Profile</p>
                <div className="msg-container">
                </div>
                <div className="name-container">
                    <label className="name-label">Name</label>
                    <input type="name" onLoad={ (e) =>
                        setTimeout(console.log('hello') , 1000)
                    } onChange={(e) => setName(e.target.value)} value={name} placeholder="Your Name" htmlFor="name" />
                </div>
                <div className="email-container">
                    <label className="email-label">Email Address</label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email address" htmlFor="email" />
                </div>
                <div className="password-container">
                    <label className="password-label">Password</label>
                    <input type="password" placeholder="Password" htmlFor="password" />
                </div>
                <div className="password-container">
                    <label className="password-label">Confirm Password</label>
                    <input type="password" placeholder="Confirm Password" htmlFor="password" />
                </div>
                <button onClick={handleUpdate} className="submit">Update</button>
                </div>
                <div className="my-orders">
                <div className="title">My Orders</div>
                    <table>
                    <thead>
                        <tr>
                        <td>ID</td>
                        <td>DATE</td>
                        <td>TOTAL</td>
                        <td>PAID</td>
                        <td>DELIVERED</td>
                        <td />
                        </tr>
                    </thead>
                    <tbody>
                        {!loadingOrders && orders.map(order => (
                        <tr key={order._id}>
                        <td>{order._id}</td>
                        <td>{order.createdAt.substring(0, 10)}</td>
                        <td>{order.totalPrice}</td>
                        <td>{order.isPaid ? (
                      order.paidAt.substring(0, 10)
                    ) : (
                      <i className='fas fa-times' style={{ color: 'red' }}></i>
                    )}</td>
                        <td>{order.isDelivered ? (
                      order.deliveredAt.substring(0, 10)
                    ) : (
                      <i className='fas fa-times' style={{ color: 'red' }}></i>
                    )}</td>
                        <td><Link to={`/order/${order._id}`}><button className="details">Details</button></Link></td>
                        </tr>
                    ))}
                    </tbody>
                    </table>
                </div>
            </div>
        </section>

    )
}

export default Profile