import React , {useState , useEffect} from 'react'
import { useDispatch } from 'react-redux';
import '../css/login.css'
import {userLogin} from '../actions/userActions'
import {useSelector} from 'react-redux'
import { Link } from 'react-router-dom';

function Login({history}) {

    const [email , setEmail] = useState(null);
    const [password , setPassword] = useState(null);

    const dispatch = useDispatch()

    const {error , userData , loading} = useSelector(state => state.userLogin);

    const handleSubmit = () => {
        if(email && password) {
        dispatch(userLogin(email , password));
        }
    }


    useEffect( 
        () => {
        if(userData) {
            history.push('/')
        }
    }
    )



    return (
        <section id="login">
            <p className="title">SIGN IN</p>
            <div className="msg-container">
                {error && <p>Check your email id and password</p>}
            </div>
            <div className="email-container">
                <label className="email-label">Email Address</label>
                <input onChange = {e => setEmail(e.target.value)} type="email" placeholder="email address" htmlFor="email" />
            </div>
            <div className="password-container">
                <label className="password-label">Password</label>
                <input onChange = {e => setPassword(e.target.value)} type="password" placeholder="Password" htmlFor="password" />
            </div>
            <button onClick ={handleSubmit} className="submit">Submit</button>
            <div className="new">New Customer ? <Link to='/register'> Register </Link> </div>
        </section>

    )
}

export default Login