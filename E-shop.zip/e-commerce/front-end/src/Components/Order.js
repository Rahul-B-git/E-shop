import React, { useState , useEffect } from 'react'
import Nav from './OrderNav'
import '../css/order.css'
import { useSelector , useDispatch } from 'react-redux'
import {saveOrder} from '../actions/orderActions'

const Order = ({history}) => {

    const address = useSelector(state => state.address);
    const paymentMethod = useSelector(state => state.paymentMethod);
    const items = useSelector(state => state.cart.cartItems)


    const itemsPrice = items.reduce((acc , item) => acc + item.price , 0).toFixed(2);

    const shippingPrice = itemsPrice * (itemsPrice < 100 ? 0.03 : 0).toFixed(2);

    const taxPrice = (Number(itemsPrice) * 0.18).toFixed(2);

    const totalPrice = (Number(itemsPrice) + Number(shippingPrice) + Number(taxPrice));

    const dispatch = useDispatch();

        const order = useSelector(state => state.order);
        const [id , setId] = useState(null);

    useEffect(() => {

        if(order.orderDetails) {
            setId(order.orderDetails._id)
        }

    }, [order])

    const handlePlaceOrder = async () => {
        dispatch(saveOrder({
            // console.log({
            orderItems : items,
            shippingAddress : address,
            paymentMethod : paymentMethod,
            itemsPrice : itemsPrice,
            taxPrice : taxPrice,
            shippingPrice : shippingPrice,
            totalPrice : totalPrice
        }))

        if(id) {
            history.push(`/order/${id}`)
        }

    }

    return (
        <>
            <Nav step1 step2 step3 step4 />
            <section id="order-page">
                <div id="left">
                    <div className="shipping">
                    <p className="title">SHIPPING</p>
                    <p className="value">Address : {address.address} , {address.city} {address.postCode}, {address.country}</p>
                    <hr />
                    </div>
                    <div className="payment-method">
                    <p className="title">PAYMENT METHOD</p>
                    <p className="value">Method : {paymentMethod}</p>
                    <hr />
                    </div>
                    <div className="order-items-container">
                    <p className="title">Order Items</p>

                    {items.map(item => (                    
                    <div key={item.product} className="item">
                        <img src={item.image} />
                    <p className="item-title">{item.name}</p>
                        <p className="details"> {item.qty} x Rs{item.price} = Rs{item.qty * item.price}</p>
                    </div>))}
                    </div>
                </div>
                <div id="right">
                    <div className="title">
                    Order Summary
                    </div>
                    <div className="items-summary row">
                    <p className="value">Items</p>
                    <p className="value">Rs{itemsPrice}</p>
                    </div>
                    <div className="shipping-summary row">
                    <p className="value">Shipping</p>
                    <p className="value">Rs{shippingPrice}</p>
                    </div><div className="tax-summary row">
                    <p className="value">Tax</p>
                    <p className="value">Rs{taxPrice}</p>
                    </div><div className="total-summary row">
                    <p className="value">total</p>
                    <p className="value">Rs{totalPrice}</p>
                    </div>
                    <button onClick={handlePlaceOrder} className="submit">Place order</button>
                </div>
            </section>

        </>
    );
}

export default Order
