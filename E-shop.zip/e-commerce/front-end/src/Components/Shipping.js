import React , {useEffect, useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { saveAddress } from '../actions/orderActions';
import '../css/shipping.css'
import Nav from './OrderNav'

const Shipping = ({history}) => {
    const shippingAddress = useSelector((state) => state.address)
    const [address , setAddress] = useState(shippingAddress.address);
    const [city , setCity] = useState(shippingAddress.city);
    const [postalCode , setPostCode] = useState(shippingAddress.postalCode);
    const [country , setCountry] = useState(shippingAddress.country);
    const dispatch = useDispatch();
    const handleClick = () => {
    dispatch(saveAddress({address , city , postalCode , country}));
    history.push('/payment');
}

console.log(address)

    return (
        <>
        <Nav step1 step2 />
        <section id="shipping">
        <p className="title">Shipping</p>
        <div className="msg-container">
        </div>
        <div className="email-container">
            <label className="address-label">Address</label>
            <input onChange={(e) => setAddress(e.target.value)} value={address} type="text" placeholder="address" htmlFor="address" required />
        </div>
        <div className="city-container">
            <label className="city-label">City</label>
            <input onChange={(e) => setCity(e.target.value)} value={city} type="text" placeholder="City" htmlFor="password" required/>
        </div>
        <div className="postal-container">
            <label className="postal-label">Postal Code</label>
            <input onChange={(e) => setPostCode(e.target.value)} value={postalCode} type="number" placeholder="Postal Code" htmlFor="postal code" required/>
        </div>
        <div className="country-container">
            <label className="country-label">Country</label>
            <input value={country} onChange={(e) => setCountry(e.target.value)} type="text" placeholder="Country" htmlFor="country" required/>
        </div>
        <button onClick = {handleClick} className="submit">Continue</button>
        </section>
        </>
    )
}

export default Shipping