import React , {useEffect} from 'react'
import {useDispatch , useSelector} from 'react-redux'
import { Link } from 'react-router-dom'
import {addToCart , removeFromCart} from '../actions/cartActions'
import '../css/cart.css'

const Cart = ({match , location}) => {

    const dispatch = useDispatch();

    const id = match.params.id ?match.params.id.split('=')[1] : false
    const qt = location.search ? location.search.split('=')[1] : false


    useEffect(() => {

    if(id) {
    dispatch(addToCart(id , Number(qt)));
    }
    } , [dispatch , id , qt])

    let cart = useSelector((state) => state.cart.cartItems);
    let userLogin = useSelector((state) => state.userLogin);


    return(
        <section id="cart" className="container">
        <div id="left-container">
        <div className="heading">Shopping Cart</div>
        <div className="list-items-container">
        {(cart.length >=1 ) && 
    
        (cart.map(item => 
    
        <div key={item.name} className="list-item">
            <img src={item.image} />
            <div className="title">{item.name}</div>
            <div className="price">Rs{item.price}</div>
            <div className="quantity-container">
            <select name="qts" defaultValue={item.qty} onChange = {e => dispatch(addToCart(item.product , Number(e.target.value)))}>
                {[...Array(item.countInStock).keys()].map(item => <option key={item} value={item+1}>{item+1}</option>)}
            </select>
            </div>
            <div href = '#'  onClick={() => dispatch(removeFromCart(item.product))} className="remove-item"><i className="fas fa-trash" /></div>
        </div>
        
    ))
    
    }
    </div>
  </div>
  <div id="right-container">
    <div className="inside">
      <p className="subtotal">SUBTOTAL ({cart.length}) ITEMS</p>
      <p className="subrate">Rs{
          cart.length == 0 ? '0' : (cart.reduce((acc , item) => Number(acc) + Number(item.qty) * Number(item.price) , 0))
        }</p>
      <Link to = {(userLogin) ? '/shipping' : '/login'}><button>Proceed to checkout</button></Link>
    </div>
  </div>
</section>

    );

}

export default Cart;