import { Link } from 'react-router-dom'
import Ratings from './Ratings'
import axios from 'axios'

const Product = ({ product }) => {

    return ( <div className = "product" >
        <div className = "product-padding" >
        <img style = {{ width: "100%" } }
        src = { product.image }
        /> <Link to = { `/product/${product._id}` }
        className = "title" > { product.name } </Link> 
		<div className = "ratings" > < Ratings rate = { product.rating }/> ratings</div >
        <div className = "price" > Rs{product.price} </div> 
		</div> 
		</div>
    );

}

export default Product;