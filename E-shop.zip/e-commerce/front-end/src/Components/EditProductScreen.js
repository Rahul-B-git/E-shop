import Axios from 'axios'
import React, { useEffect, useState } from 'react'
import {useSelector , useDispatch} from 'react-redux'
import { fetchProduct, updateProduct } from '../actions/productActions'
import {getUserEdit , updateEditUser} from '../actions/userActions'
import '../css/editscreen.css'
import { PRODUCT_GENERATE_RESET, PRODUCT_GET_RESET, PRODUCT_UPDATE_RESET } from './constants/constants'

const UserEditScreen = ({match , history}) => {

    const id = match.params.id;

    const dispatch = useDispatch();

    //states
    const [name , setName] = useState('');
    const [price , setPrice] = useState(0)
    const [image , setImage] = useState(' ')
    const [brand , setBrand] = useState('')
    const [countInStock , setCountInStock] = useState('')
    const [category , setCategory] = useState('')
    const [description , setDescription] = useState('')

    const productDetails = useSelector(state => state.productReducers);
    const {loading , product} = productDetails;

    const productUpdate = useSelector(state => state.productUpdate)
    const {loading:loadingUpdate , success:successUpdate , product : updatedProduct} = productUpdate;
    
    useEffect(() => {
        if(successUpdate) {
            history.push('/admin/products');
            dispatch({type : PRODUCT_GET_RESET})
            dispatch({type : PRODUCT_UPDATE_RESET})
        } else {
                if (!product || product._id != id ) {
                dispatch(fetchProduct(id))
                } else {
                    setName(product.name)
                    setPrice(product.price)
                    setImage(product.image)
                    setBrand(product.brand)
                    setCategory(product.category)
                    setCountInStock(product.countInStock)
                    setDescription(product.description)
                }
        }
        } , [dispatch , history , successUpdate , product , id])

    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(updateProduct({_id : product._id , name , price , image, brand , category , countInStock, description ,}))
        dispatch({type : PRODUCT_GENERATE_RESET})
    }

    const handleUpload = async (e) => {
        const file = e.target.files[0];

        const formData = new FormData();
        formData.append('image' , file);
        
        try {
            const header = {headers : {'Content-Type' : 'multipart/form-data'}}
            const {data} =  await Axios.post('http://localhost:5000/api/upload' , formData , header);

            setImage(data);
        } catch(error){
            console.log(error);
        }
    }

    return ( !loading &&
        <section id="product-edit">
            <form>
                    <p className="title">Edit Product</p>
                    <p className="goback">Go Back</p>
                    <div className="msg-container">
                    </div>
                    <div className="name-container">
                        <label className="name-label">Name</label>
                        <input value={name} onChange = {e => setName(e.target.value)} type="name" placeholder="name" />
                    </div>
                    <div className="price-container">
                        <label className="price-label">Price</label>
                        <input value={price} onChange = {e => setPrice(e.target.value)} type="number" placeholder="price"  />
                    </div>
                    <div className="image-container">
                        <label className="image-label">Image</label>
                        <input value={image} onChange = {e => setImage(e.target.value)} type="text" placeholder="image"/>
                        <input onChange={handleUpload} style={{display: "block"}} type="file"></input>
                    </div>        
                    <div className="brand-container">
                        <label className="brand-label">Brand</label>
                        <input value={brand} onChange = {e => setBrand(e.target.value)} type="text" placeholder="brand"  />
                    </div>
                    <div className="category-container">
                        <label className="category-label">category</label>
                        <input value={category} onChange = {e => setCategory(e.target.value)} type="text" placeholder="category"/>
                    </div>
                    <div className="countInStock-container">
                        <label className="countInStock-label">Count InStock</label>
                        <input value={countInStock} onChange = {e => setCountInStock(e.target.value)} type="number" placeholder="countInStock" />
                    </div>
                    <div className="description-container">
                        <label className="description-label">Description</label>
                        <input value={description} onChange = {e => setDescription(e.target.value)} type="text" placeholder="description"/>
                    </div>
                    
                    <button onClick={handleSubmit} className="submit">Submit</button>
            </form>
        </section>
    );
}

export default UserEditScreen ;
