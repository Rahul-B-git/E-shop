import React, { useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import {deleteUser, getAllUsers} from '../actions/userActions'
import '../css/allusers.css'
const AllUsers = () => {

    const dispatch = useDispatch()

    const allUsers = useSelector(state => state.allUsers);

    const {loading ,users} = allUsers;

    useEffect(() => {
        dispatch(getAllUsers())
    } , [dispatch])

    if(!loading) {
        console.log('Not loading.........')
        console.log(users);
    }

return (<>

    <p className="title">All users</p>

    <table>
        <thead>
            <tr>
                <td>ID</td>
                <td>NAME</td>
                <td>EMAIL</td>
                <td>ADMIN</td>
                <td></td>
            </tr>
        </thead>
        <tbody>
            {!loading && users.map(user => (
                <tr key={user._id}>
                    <td>{user._id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.isAdmin ? <i className="fas fa-check green"></i> : <i className="fas fa-times red"></i>}</td>
                    <td><Link to={`/admin/user/${user._id}`}>
                            <button>
                                <i style={{cursor: "pointer"}} className='fas fa-edit bg-white'></i>
                            </button>
                        </Link>
                        <button onClick= {() => {
                            if(window.confirm('Are you sure you want to delete the account ?')) {
                                dispatch(deleteUser(user._id))
                                dispatch(getAllUsers())
                            }
                            }}>
                            <i className='fas fa-trash bg-red'></i>
                        </button>
                    </td>
                </tr>
            ))}
        </tbody>
    </table>

</>)}

export default AllUsers
