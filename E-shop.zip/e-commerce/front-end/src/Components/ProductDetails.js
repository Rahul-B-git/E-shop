import React , {useEffect , useState} from 'react'
import {useSelector , useDispatch} from 'react-redux'
import {Link} from 'react-router-dom'
import Ratings from './Ratings'
import {fetchProduct , addReview} from '../actions/productActions'
import {addToCart} from '../actions/cartActions'
import '../css/productDetails.css'
import { PRODUCT_REVIEW_RESET } from './constants/constants'

function ProductDetails({match}) {

    const [rating, setRating] = useState(null);
    const [comment, setComment] = useState('');

    const dispatch = useDispatch();

    const { product , loading , errorReview} = useSelector(state => state.productReducers);

    const count = product.countInStock;

    const review = useSelector(state => state.addReview);
    const {success ,loading:loadingReview , error} = review

    const [qty , setqty] = useState(1);


    useEffect( () => {
        dispatch(fetchProduct(match.params.id));
    } , [dispatch , match]
    )

    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(addReview(match.params.id , {rating , comment}))

        if(success){
        dispatch(fetchProduct(match.params.id));
        dispatch({type : PRODUCT_REVIEW_RESET})
        }
    }

    return (
        <>
            <section id="products-page">
            <div className="go-back">
            <Link to="/"><i className="fas fa-arrow-alt-circle-left" /> GO BACK</Link>
            </div>
            <div className="products-main">
            <div className="image-container">
                <img src={product.image} />
            </div>
            <div className="details-container">
                <div className="content">
                <div className="title details">
                    {product.name}
                </div>
                <div className="ratings">
                    <Ratings rate = {product.rating} /> {product.rating} reviews
                </div>
                <div className="price">
                    Price : Rs{product.price}
                </div>
                <div className="description">
                    {product.description}
                </div>
                </div>
                <div className="checkout">
                <ul>
                    <div className="price-checkout">
                    <li>Price: </li>
                    <li>Rs{product.price}</li>
                    </div>
                    <div className="status-checkout">
                    <li> Status: </li>
                    <li>{product.countInStock > 0 ? 'In stock' : 'Out of Stock'}</li>
                    {product.countInStock > 0}
                    </div>
                    <div>
                    { (product.countInStock > 0) && 
                        (
                    <div className="qts-display">
                        <li>Quantity : </li>
                        <li>
                        <select name="qts" defaultValue = {qty} onChange={e => setqty(e.target.value)}>
                            {[...Array(product.countInStock).keys()].map(item => <option key={item} value={item+1}>{item+1}</option>)}
                        </select>
                        </li>
                    </div>
                )
                    }
                    </div>
                    <Link to={`/cart/id=${product._id}?qty=${qty}`}><button className="addCart">Add to cart</button></Link>
                </ul>
                </div>
            </div>
            </div>
            </section>
            <section id="comments">
                {product.reviews.length > 0 ? product.reviews.map(review => (
                    <div key={review.name} className="comment">
                    <p className="name">{review.name}</p>
                    <div className="ratings">
                    <Ratings rate = {review.rating} />
                    </div>
                    {review.createdAt.substring(0 , 10)}
                    <p className="message">{review.comment}</p>
                    
                    <hr />
                    </div>
                ))
                 : <p style={{color: "white" , background : "orange" , width: "fit-content" , padding : "5px 10px"}}>No comments</p>    
                }
            </section>
            <section id="add-review">
                {errorReview == 'Review already exits' && <p>Review Already Exists</p>}
                <p className="title">Write a customer review</p>
                <form className="form">
                    <label>Ratings </label>
                    <select required defaultValue={rating} onChange = {(e) => setRating(e.target.value)} htmlFor="rating">
                        <option defaultChecked value="select..">Select.....</option>
                        <option value="5">5 - Excellent</option>
                        <option value="4">4 - Very Good</option>
                        <option value="3">3 - Average</option>
                        <option value="2">2 - poor</option>
                        <option value="1">4 - Very Poor</option>
                    </select>
                    <label htmlFor="message" className="message-label">Comment</label>
                    <textarea required type="message" onChange={(e) => setComment(e.target.value)} value={comment} />
                    <button onClick={handleSubmit} style={{display: "block" , padding : "5px 10px" }} type="submit">ADD COMMENT</button>
                </form>
            </section>
            </>
    );

}

export default ProductDetails
