import {useEffect} from 'react';
import {useSelector , useDispatch} from 'react-redux'
import Product from './Product';
import {fetchProducts} from '../actions/productActions'

const Index = () => {

    const dispatch = useDispatch();

    const productsReducer = useSelector((state) => state.productsReducer);
    const { products , loading , error } = productsReducer;

    useEffect(() => {
        //dispatch products
        dispatch(fetchProducts());
    }, [dispatch])


    return (
        <section id="products">
            <div className="heading">Latest Products</div>
            <div className="products-container">
            {
                products.map(product => <Product key={product._id} product = {product} />)
            }
            </div>
            </section>

    );
}

export default Index;