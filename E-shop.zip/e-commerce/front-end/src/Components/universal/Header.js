import { Link } from 'react-router-dom'
import {useSelector , useDispatch} from 'react-redux'
import {logout} from '../../actions/userActions'

const Header = ({history}) => {

    const login = useSelector(state => state.userLogin);

    const dispatch = useDispatch();

    const {userData} = login;

    const handleLogOut = () => {
        dispatch(logout());
    }

    return (    <header>
        <div className="header-container">
            <div id="title">
                    <Link to='/'>
                        E-Shop
                    </Link>
            </div>
            <div id="nav">
                <nav id="nav">
                    <ul className="nav-ul">
                        <li><Link to="/cart"><i className="fas fa-shopping-cart"></i> CART</Link></li>
                        {!userData && <li><Link to="/login"> <i className="fas fa-user"></i> SIGN IN</Link></li>}
                        {userData && <ul className="cursor ul" onClick = {(e) => {
                            document.querySelector('.profile').style.display = 'block';
                            document.querySelector('.logout').style.display = 'block';
                        }}><li className="block"> {(userData.name)} <i className="fas fa-caret-down"></i></li>
                            <ul className="ul-container">
                                <Link to="/profile"><li onClick = { (e) => {

                                    setTimeout(() => {
                                        document.querySelector('.profile').style.display = 'none';
                                        document.querySelector('.logout').style.display = 'none';
                                    } , 1000);
                                    
                                }} className="hidden profile cursor">profile</li></Link>
                                <li onClick={handleLogOut} className="hidden logout">Logout</li>
                            </ul>
                        </ul>}
                        {(userData && userData.isAdmin ?
                            <>
                            <ul className="admin-ul">
                                <li onClick={() => {
                                    document.querySelector('.admin-users').style.display = 'block';
                                    document.querySelector('.admin-products').style.display = 'block';
                                    document.querySelector('.admin-orders').style.display = 'block';
                                }}>Admin <i className="fas fa-caret-down"></i></li>
                                <ul className="admin-nav">
                                    <Link to="/admin/users">
                                        <li onClick={() => {
                                            setTimeout(() => {
                                                document.querySelector('.admin-users').style.display = 'none';
                                                document.querySelector('.admin-products').style.display = 'none';
                                                document.querySelector('.admin-orders').style.display = 'none';                                            
                                            } , 3000)
                                        }} className="admin-users">Users</li>
                                    </Link>
                                    <Link to="/admin/products">
                                        <li onClick={() => {
                                            setTimeout(() => {
                                                document.querySelector('.admin-users').style.display = 'none';
                                                document.querySelector('.admin-products').style.display = 'none';
                                                document.querySelector('.admin-orders').style.display = 'none';                                            
                                            } , 3000)}} className="admin-products">Products</li>                                    
                                    </Link>
                                    <Link to="/admin/orders">
                                        <li onClick={() => {
                                        setTimeout(() => {
                                            document.querySelector('.admin-users').style.display = 'none';
                                            document.querySelector('.admin-products').style.display = 'none';
                                            document.querySelector('.admin-orders').style.display = 'none';                                            
                                        } , 3000)}} className="admin-orders">Orders</li>
                                    </Link>
                                </ul>
                            </ul>
                            </>
                        : console.log('Hello'))}
                    </ul>
                </nav>
            </div>
        </div>
    </header>
);
}

export default Header;