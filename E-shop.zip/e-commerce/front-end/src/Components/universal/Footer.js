const Footer = () => {
    return(
        <footer>
        CopyRight &copy; E-Shop
        </footer>);
}

export default Footer;