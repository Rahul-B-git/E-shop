import React, { useEffect, useState } from 'react'
import {useSelector , useDispatch} from 'react-redux'
import {getUserEdit , updateEditUser} from '../actions/userActions'
import '../css/editscreen.css'
import { USER_EDIT_GET_RESET, USER_EDIT_REQUEST } from './constants/userConstants'

const UserEditScreen = ({match , history}) => {

    const id = match.params.id;

    console.log(id)

    const dispatch = useDispatch();

    const userDetails  = useSelector(state => state.userDetails);
    const {loading , error , userData} = userDetails;

    const updateUser  = useSelector(state => state.updateUser);
    const {loading : loadingUpdate , success:successUpdate , error : errorUpdate} = updateUser;


    const [name , setName] = useState('');
    const [email , setEmail] = useState('');
    const [isAdmin , SetIsAdmin] = useState(false);

    useEffect(() => {
        
        if(successUpdate) {
            setName('');
            setEmail('');
            SetIsAdmin('');
            dispatch({type : USER_EDIT_REQUEST})
            dispatch({type : USER_EDIT_GET_RESET})
            history.push('/admin/users')
        } else {
            if(!userData) {
                dispatch(getUserEdit(id)); 
            } else {
                setName(userData.name)
                setEmail(userData.email)
                SetIsAdmin(userData.isAdmin)
            }
        }
    }, [dispatch , id , userData , updateUser , successUpdate])

    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(updateEditUser({name , email , isAdmin , _id : id}));
        }



    return ( !loading && 
        <section id="user-edit">
            <form>
                    <p className="title">Edit user</p>
                    <p className="goback">Go Back</p>
                    <div className="msg-container">
                    </div>
                    <div className="name-container">
                        <label className="name-label">Name</label>
                        <input value={name} onChange = {e => setName(e.target.value)} type="name" placeholder="name" htmlFor="name" />
                    </div>
                    <div className="email-container">
                        <label className="email-label">email</label>
                        <input value={email} onChange = {e => setEmail(e.target.value)} type="email" placeholder="email" htmlFor="email" />
                    </div>
                    <div className="checkbox isAdmin">
                        <input className="checkbox-input" type="checkbox" onChange={(e) => SetIsAdmin(e.target.checked)} checked={isAdmin} value="Is Admin" />
                        <label className="checkbox-label">Is Admin</label>
                    </div>
                    <button onClick={handleSubmit} className="submit">Submit</button>
            </form>
        </section>
    );
}

export default UserEditScreen
