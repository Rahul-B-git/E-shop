import {ORDER_DELIVER_REQUEST , ORDER_DELIVER_SUCCESS , ORDER_DELIVER_FAIL , ORDER_DETAILS_FAIL, ORDER_DETAILS_REQUEST, ORDER_DETAILS_SUCCESS, ORDER_LIST_FAIL, ORDER_LIST_MY_FAIL, ORDER_LIST_MY_REQUEST, ORDER_LIST_MY_SUCCESS, ORDER_LIST_REQUEST, ORDER_LIST_SUCCESS, ORDER_PAY_FAIL, ORDER_PAY_REQUEST, ORDER_PAY_SUCCESS, ORDER_PROCEED_ERROR, ORDER_PROCEED_REQUEST, ORDER_PROCEED_SUCCESS, SAVE_PAYMENT_DETAILS, SAVE_SHIPPING_DETAILS } from "../Components/constants/orderConstants";
import axios from 'axios'

export const saveAddress = (data) => async (dispatch) => {
    dispatch ({type : SAVE_SHIPPING_DETAILS , payload : data });
    
    localStorage.setItem('ShippingAddress' , JSON.stringify(data));
}

export const savePaymentMethod = (data) => async (dispatch) => {
    dispatch ({type : SAVE_PAYMENT_DETAILS , payload : data });
    
    localStorage.setItem('PaymentMethod' , JSON.stringify(data));
}

export const saveOrder = (details) => async (dispatch , getState) => {

    dispatch({type : ORDER_PROCEED_REQUEST});

    const headers = {headers : {
        'Content-Type' : 'application/json',
        'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
    }}

    try {
        const {data} = await axios.post('http://localhost:5000/api/orders' , details , headers);
        dispatch({type : ORDER_PROCEED_SUCCESS , success : true , payload : data})
    }
    catch (error) {
        dispatch({type : ORDER_PROCEED_ERROR , payload : error})
    }

}

export const getOrderDetails = (id) => async (dispatch, getState) => {
  try {
    dispatch({
      type: ORDER_DETAILS_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        'Authorization': `Bearer ${userData.token}`,
      },
    }

    const { data } = await axios.get(`/api/orders/${id}`, config)

    dispatch({
      type: ORDER_DETAILS_SUCCESS,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: ORDER_DETAILS_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}

export const payOrder = (orderId, paymentResult) => async (
  dispatch,
  getState
) => {
  try {
    dispatch({
      type: ORDER_PAY_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${userData.token}`,
      },
    }

    const { data } = await axios.put(
      `/api/orders/${orderId}/pay`,
      paymentResult,
      config
    )

    console.log(data);

    dispatch({
      type: ORDER_PAY_SUCCESS,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: ORDER_PAY_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}

export const listMyOrders = () => async (dispatch, getState) => {
  try {
    dispatch({
      type: ORDER_LIST_MY_REQUEST,
    })

    const {
      userLogin
    } = getState()

    const config = {
      headers: {
        Authorization: `Bearer ${userLogin.userData.token}`,
      },
    }

    const { data } = await axios.get(`http://localhost:5000/api/orders/myorders`, config)

    dispatch({
      type: ORDER_LIST_MY_SUCCESS,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: ORDER_LIST_MY_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}

export const listOrders = () => async (dispatch, getState) => {
  try {
    dispatch({
      type: ORDER_LIST_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        Authorization: `Bearer ${userData.token}`,
      },
    }

    const { data } = await axios.get(`/api/orders`, config)

    dispatch({
      type: ORDER_LIST_SUCCESS,
      payload: data,
    })

  } catch (error) {
    dispatch({
      type: ORDER_LIST_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}

export const deliverOrder = (order) => async (dispatch, getState) => {
  try {
    dispatch({
      type: ORDER_DELIVER_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        Authorization: `Bearer ${userData.token}`,
      },
    }

    const { data } = await axios.put(
      `/api/orders/${order._id}/deliver`,
      {},
      config
    )

    dispatch({
      type: ORDER_DELIVER_SUCCESS,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: ORDER_DELIVER_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}