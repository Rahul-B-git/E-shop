import axios from 'axios'
import {ADD_TO_CART , REMOVE_FROM_CART} from'../Components/constants/constants'

export const addToCart = (id , qty) =>  async (dispatch  , getState) => {
    const {data} = await axios.get(`http://localhost:5000/api/products/${id}`);

    dispatch({type : ADD_TO_CART , payload : {
        name : data.name,
        image : data.image,
        price : data.price,
        qty : qty,
        countInStock : data.countInStock,
        product : data._id
    }
    });
  localStorage.setItem('cartItems', JSON.stringify(getState().cart.cartItems))
}

export const removeFromCart = (id) => async (dispatch , getState) => {

  dispatch ({type : REMOVE_FROM_CART , payload : {
    id : id
  }});

  localStorage.setItem('cartItems', JSON.stringify(getState().cart.cartItems))

}
