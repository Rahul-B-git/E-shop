import axios from 'axios';
import { PRODUCT_UPDATE_REQUEST , PRODUCT_UPDATE_SUCCESS , PRODUCT_UPDATE_ERROR, PRODUCTS_GET_ERROR, PRODUCTS_GET_STATE, PRODUCTS_LOAD_STATE , PRODUCT_DELETE_ERROR, PRODUCT_DELETE_REQUEST, PRODUCT_DELETE_SUCCESS, PRODUCT_GET_ERROR ,PRODUCT_GET_STATE , PRODUCT_LOAD_STATE, PRODUCT_GENERATE_SUCCESS, PRODUCT_GENERATE_ERROR, PRODUCT_GENERATE_REQUEST, PRODUCT_REVIEW_REQUEST, PRODUCT_REVIEW_SUCCESS, PRODUCT_REVIEW_ERROR } from '../Components/constants/constants';

export const fetchProducts = () => async (dispatch) => {

    dispatch ({type : PRODUCTS_LOAD_STATE , loading : true })
    
    const {data} = await axios.get('http://localhost:5000/api/products');

    try {
        dispatch({type : PRODUCTS_GET_STATE , loading : false , payload : data});
    } catch (error){
        dispatch({type : PRODUCTS_GET_ERROR , error : error});
    }
}

export const fetchProduct = (id) => async (dispatch) => {

    dispatch ({type : PRODUCT_LOAD_STATE , loading : true })
    

    try {
        const {data} = await axios.get(`http://localhost:5000/api/products/${id}`);
        dispatch({type : PRODUCT_GET_STATE , loading : false , payload : data});
    } catch (error){
        dispatch({type : PRODUCT_GET_ERROR , error : error});
    }
}

export const deleteProduct = (id) => async(dispatch , getState) => {

    dispatch({type : PRODUCT_DELETE_REQUEST , loading : true})

    try {
            const header = { headers : {
                'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
            }
            }

            const {data} = await axios.delete(`http://localhost:5000/api/products/remove/${id}` , header);

            dispatch({type: PRODUCT_DELETE_SUCCESS , success : true , loading : false});
        }
     catch (error) {
        console.log(error);
        dispatch({type : PRODUCT_DELETE_ERROR , success : false , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})       
    }    

}

export const updateProduct = (product) => async (dispatch, getState) => {
  try {
    dispatch({
      type: PRODUCT_UPDATE_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${userData.token}`,
      },
    }

    const { data } = await axios.put(
      `/api/products/${product._id}`,
      product,
      config
    )

    dispatch({
      type: PRODUCT_UPDATE_SUCCESS,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: PRODUCT_UPDATE_ERROR,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}


export const generateProduct = () => async (dispatch, getState) => {
  try {
    dispatch({
      type: PRODUCT_GENERATE_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${userData.token}`,
      },
    }

    const { data } = await axios.get(
      `/api/products/generate`,
      config
    )

    dispatch({
      type: PRODUCT_GENERATE_SUCCESS,
      success : true,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: PRODUCT_GENERATE_ERROR,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}

export const addReview = (productId , data) => async (dispatch, getState) => {
  try {
    dispatch({
      type: PRODUCT_REVIEW_REQUEST,
    })

    const {
      userLogin: { userData },
    } = getState()

    const config = {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${userData.token}`,
      },
    }

    await axios.post(
      `/api/products/${productId}/reviews`,
      data,
      config
    )

    dispatch({
      type: PRODUCT_REVIEW_SUCCESS,
      success : true,
    })
  } catch (error) {
    dispatch({
      type: PRODUCT_REVIEW_ERROR,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    })
  }
}