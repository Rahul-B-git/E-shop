import axios from 'axios'
import { USER_LOGIN_ERROR, USER_LOGIN_REQUEST, USER_LOGIN_SUCCESS, USER_LOGOUT , USER_REGISTER_ERROR , USER_REGISTER_SUCCESS , USER_REGISTER_REQUEST, USER_GET_REQUEST, USER_GET_SUCCESS, USER_GET_ERROR, USERS_GET_REQUEST, USERS_GET_SUCCESS, USERS_GET_ERROR, USER_DELETE_REQUEST, USER_DELETE_SUCCESS, USER_DELETE_ERROR, USER_EDIT_GET_REQUEST, USER_EDIT_GET_SUCCESS, USER_EDIT_GET_ERROR, USER_EDIT_REQUEST, USER_EDIT_SUCCESS, USER_EDIT_ERROR} from '../Components/constants/userConstants';

export const userLogin = (email , password) => async (dispatch) => {

    dispatch({type : USER_LOGIN_REQUEST , loading : true })

    const headers = {headers : {
        'Content-Type' : 'application/json'
    }}
    

    try {
        const {data} = await axios.post('http://localhost:5000/api/users/login' , {email , password} , headers);
        dispatch({type : USER_LOGIN_SUCCESS , payload : data , loading : false});
        localStorage.setItem('userData' , JSON.stringify(data));

    } catch (error) {
        console.log(error);
        dispatch({type : USER_LOGIN_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})
    }
}

export const logout = () => async (dispatch) => {
    localStorage.removeItem('userData');
    dispatch({type : USER_LOGOUT})
}

export const registerUser = (name , email , password) => async (dispatch) => {

    try {
        dispatch({type : USER_REGISTER_REQUEST , loading : true })

        const headers = {headers : {
            'Content-Type' : 'application/json'
        }}
        const {data} = await axios.post('http://localhost:5000/api/users/register' , {name , email , password} , headers);
        dispatch({type : USER_REGISTER_SUCCESS , payload : data , loading : false});
        dispatch({type : USER_LOGIN_SUCCESS , payload : data , loading : false});
        localStorage.setItem('userData' , JSON.stringify(data));

    } catch (error) {
        console.log(error);
        dispatch({type : USER_REGISTER_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})
    } 
}

export const getUser = () => async(dispatch , getState) => {

    dispatch({type : USER_GET_REQUEST , loading : true })

    const headers = {headers : {
        'Content-Type' : 'application/json',
        'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
    }}
    

    try {
        const {data} = await axios.get('http://localhost:5000/api/users/profile', headers);
        dispatch({type : USER_GET_SUCCESS , payload : data , loading : false});

    } catch (error) {
        console.log(error);
        dispatch({type : USER_GET_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})
    }
}

export const updateUser = (id , name , email , password) => async(dispatch , getState) => {

    dispatch({type : USER_GET_REQUEST , loading : true })

    const headers = {headers : {
        'Content-Type' : 'application/json',
        'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
    }}
    

    try {
        const {data} = await axios.put('http://localhost:5000/api/users/profile' , {id , name , email , password} , headers);
        dispatch({type : USER_GET_SUCCESS , payload : data , loading : false});

    } catch (error) {
        console.log(error);
        dispatch({type : USER_GET_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})
    }
}

export const getAllUsers = () => async(dispatch , getState) => {

    dispatch({type : USERS_GET_REQUEST , loading : true})

    try {
            const header = { headers : {
                'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
            }
            }

            const {data} = await axios.get('http://localhost:5000/api/users' , header);

            dispatch({type: USERS_GET_SUCCESS , payload : data , loading : false});
        }
     catch (error) {
        console.log(error);
        dispatch({type : USERS_GET_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})       
    }

}

export const deleteUser = (id) => async(dispatch , getState) => {

    dispatch({type : USER_DELETE_REQUEST , loading : true})

    try {
            const header = { headers : {
                'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
            }
            }

            const {data} = await axios.delete(`http://localhost:5000/api/users/remove/${id}` , header);

            dispatch({type: USER_DELETE_SUCCESS , success : true , loading : false});
        }
     catch (error) {
        console.log(error);
        dispatch({type : USER_DELETE_ERROR , success : false , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})       
    }    

}

export const getUserEdit = (id) => async(dispatch , getState) => {
    dispatch({type : USER_EDIT_GET_REQUEST , loading : true })

    const headers = {headers : {
        'Content-Type' : 'application/json',
        'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
    }}
    

    try {
        const {data} = await axios.get(`http://localhost:5000/api/users/${id}`, headers);
        dispatch({type : USER_EDIT_GET_SUCCESS , payload : data , loading : false});

    } catch (error) {
        console.log(error);
        dispatch({type : USER_EDIT_GET_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})
    }
}

export const updateEditUser = (data) => async (dispatch , getState) => {

    dispatch({type : USER_EDIT_REQUEST , loading : true })

    const headers = {headers : {
        'Content-Type' : 'application/json',
        'AUTHORIZATION' : `Bearer ${getState().userLogin.userData.token}`
    }}
    

    try {
        await axios.put(`http://localhost:5000/api/users/${data._id}`, data, headers);
        dispatch({type : USER_EDIT_SUCCESS , success : true , loading : false});

    } catch (error) {
        console.log(error);
        dispatch({type : USER_EDIT_ERROR , loading : false , payload: error.response && error.response.data.message
          ? error.response.data.message
          : error.message})
    }
}