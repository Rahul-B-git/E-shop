import {BrowserRouter as Router , Switch, Route} from 'react-router-dom'
import Header from './Components/universal/Header'
import Footer from './Components/universal/Footer'
import './css/index.css'
import Index from './Components/Index'
import ProductDetails from './Components/ProductDetails.js'
import Cart from './Components/Cart'
import Login from './Components/Login'
import Register from './Components/Register'
import Profile from './Components/Profile'
import Shipping from './Components/Shipping'
import Payment from './Components/Payment'
import Order from './Components/Order'
import OrderScreen from './Components/OrderScreen'
import AllUsers from './Components/AllUsers'
import UserEditScreen from './Components/UserEditScreen'
import Products from './Components/Products'
import EditProductScreen from './Components/EditProductScreen'
import AllOrders from './Components/AllOrders'

function App() {
  return (
    <div className="App">
      <Router>
      <Header />
        <Switch>
          <Route path='/admin/orders' exact component={AllOrders} />
        <Route path='/admin/product/:id' component={EditProductScreen} />
        <Route path='/admin/products' exact component={Products} />
        <Route path='/admin/user/:id' component={UserEditScreen} />
        <Route path='/admin/users' exact component={AllUsers} />
        <Route path='/order/:id' component={OrderScreen} />
        <Route path='/order' exact component={Order} />
        <Route path="/payment" component={Payment} />
        <Route path='/shipping' component = {Shipping} />
        <Route path="/profile" component = {Profile} />
        <Route path="/register" component={Register} />
        <Route path='/login' component={Login} />
        <Route path='/' exact component={Index}/>
        <Route path='/product/:id' component={ProductDetails}/>
        <Route path='/cart/:id?' component={Cart} />
        </Switch>
      </Router>
      <Footer />
    </div>
  );
}

export default App;
